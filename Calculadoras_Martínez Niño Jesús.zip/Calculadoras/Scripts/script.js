$("document").ready(function(){

function buclePorReal(){

	var nDeriva  = document.getElementById("fNderivada").value;
	var sDeriva  = document.getElementById("fderivada").value;
	var x 		 = parseFloat(document.getElementById("valorX").value);
	var valReal  = parseFloat(document.getElementById("vReal").value);
	var valError = 0;
	var yn 		 = 0;

	for(var i=0;i<=valReal;i=valError)
	{
		var res0 	 = eval(nDeriva);
		var res1 	 = eval(sDeriva);
		var res2 	 = res0/res1;
		var resECU 	 = x - res2;
		

		var limres 	 = resECU.toFixed(5);
 		var creardiv = document.createElement("label");
  		var contenidoDe = document.createTextNode("y(" + yn + ") = " + limres + " , ");
  		creardiv.appendChild(contenidoDe);
  		var crearObjnew  = document.getElementById("resultado"); 
  		document.body.insertBefore(crearObj , crearObjnew);

  		var aux = yn + 1;
  		yn = aux;
  		valError = resECU;
	}
}




$("#send_3MN").on("click",function(){

	interpolacion();

})

function interpolacion(){

	
	var sDeriva  = document.getElementById("functioninter").value;
	var valStart = 0;
	var saveRes = new Array(4);

	for(var i=0;i<=3;i=valStart)
	{   var x = valStart;
		var res = eval(sDeriva);
		saveRes[x] = res;
		console.log(x + " " +res);
		console.log(saveRes)
		var aux = valStart + 1;
		valStart = aux;
	}

	valStart = 0;
	var saveRes2 = new Array(3);
	var numero = 0;

	for (var i=0;i<=2 ;i++){
		saveRes2[i] = saveRes[valStart+1] - saveRes[valStart]/(valStart+1) - valStart;
		var aux = valStart + 1;
		valStart = aux;
		console.log(saveRes2);
	}


	
	var saveRes3 = new Array(2);
	saveRes3[0] = SaveRes2[1] - SaveRes[0];
	saveRes3[1]
   


}



});